/// <reference types="react-scripts" />
declare module 'audio-react-recorder';
